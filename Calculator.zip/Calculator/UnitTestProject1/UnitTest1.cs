﻿using System;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestStack.White;
using TestStack.White.InputDevices;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.WindowsAPI;
using TestStack.White.UIItems.WindowStripControls;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems;
using TestStack.White.UIItems.ListBoxItems;
using System.Windows.Automation;

namespace CalculatorNew
{
    [TestClass]
    public class UnitTest1
    {
        private Application app;
        private Window win;

        [TestInitialize]
        public void Init()
        {
            app = Application.AttachOrLaunch(new ProcessStartInfo("calc"));
            win = app.GetWindow("Calculator");
        }

        [TestMethod]
        public void Addition()
        {
            //TODO
        }

        [TestCleanup]
        public void Cleanup()
        {
            app.Close();
        }
    }
}
