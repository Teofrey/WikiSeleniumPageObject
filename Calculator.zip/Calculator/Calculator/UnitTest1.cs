﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestStack.White;
using TestStack.White.InputDevices;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.WindowsAPI;
using TestStack.White.UIItems.WindowStripControls;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems;
using TestStack.White.UIItems.ListBoxItems;

namespace Calculator
{
	[TestClass]
	public class UnitTest1
	{
		private Application app;
		private Window win;

		[TestInitialize]
		public void Init()
		{
			app = Application.AttachOrLaunch(new ProcessStartInfo("calc"));
			win = app.GetWindow("Calculator");
		}

        [TestMethod]
        public void Addition()
        {
            win.Get(SearchCriteria.ByAutomationId("134")).Click();
            win.Get(SearchCriteria.ByAutomationId("93")).Click();
            win.Get(SearchCriteria.ByAutomationId("136")).Click();
            win.Get(SearchCriteria.ByAutomationId("121")).Click();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "10";

            Assert.AreEqual(result, expectedResult);
        }

        [TestMethod]
        public void Subtraction()
        {
            win.Get(SearchCriteria.ByAutomationId("136")).Click();
            win.Get(SearchCriteria.ByAutomationId("94")).Click();
            win.Get(SearchCriteria.ByAutomationId("134")).Click();
            win.Get(SearchCriteria.ByAutomationId("121")).Click();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "2";

            Assert.AreEqual(result, expectedResult);
        }

        [TestMethod]
        public void Multiplication()
        {
            win.Get(SearchCriteria.ByAutomationId("136")).Click();
            win.Get(SearchCriteria.ByAutomationId("92")).Click();
            win.Get(SearchCriteria.ByAutomationId("134")).Click();
            win.Get(SearchCriteria.ByAutomationId("121")).Click();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "24";

            Assert.AreEqual(result, expectedResult);
        }

        [TestMethod]
        public void Division()
        {
            win.Get(SearchCriteria.ByAutomationId("138")).Click();
            win.Get(SearchCriteria.ByAutomationId("91")).Click();
            win.Get(SearchCriteria.ByAutomationId("132")).Click();
            win.Get(SearchCriteria.ByAutomationId("121")).Click();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "4";

            Assert.AreEqual(result, expectedResult);
        }

        [TestMethod]
		public void AdditionalAddition()
		{
			win.Get(SearchCriteria.ByText("4").AndControlType(ControlType.Button)).Click();
			win.Get(SearchCriteria.ByText("Add").AndControlType(ControlType.Button)).Click();
            win.Get(SearchCriteria.ByText("6").AndControlType(ControlType.Button)).Click();
            win.Get(SearchCriteria.ByText("Equals").AndControlType(ControlType.Button)).Click();
            var result = win.Get(SearchCriteria
				            .ByClassName("Static")
				            .AndIndex(1)
				            .AndControlType(ControlType.Text)
				            );

            Assert.AreEqual("10",result.Name);
		}

		[TestMethod]
		public void ChangeView()
		{
			var expectedView = "Programmer";
            MenuBar menuBar = win.MenuBar;
            Menu menu = menuBar.MenuItemBy(SearchCriteria.ByText("View"));
            Menu menuProgrammer = menu.SubMenu(SearchCriteria.ByText(expectedView));

            menuProgrammer.Click();

            win.Get(SearchCriteria.ByText("1").AndControlType(ControlType.Button)).Click();
            win.Get(SearchCriteria.ByText("0").AndControlType(ControlType.Button)).Click();
            RadioButton hexRadioBtn = win.Get<RadioButton>(SearchCriteria.ByAutomationId("313"));
            hexRadioBtn.Select();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "A";

            Assert.AreEqual(expectedResult, result);

        }

        [TestMethod]
        public void ChangeViewUsingKeyboard()
        {
            Keyboard.Instance.HoldKey(KeyboardInput.SpecialKeys.ALT);
            Keyboard.Instance.Enter("2");
            Keyboard.Instance.LeaveKey(KeyboardInput.SpecialKeys.ALT);

            win.Get(SearchCriteria.ByAutomationId("135")).Click();
            win.Get(SearchCriteria.ByAutomationId("111")).Click();

            string result = win.Get(SearchCriteria.ByAutomationId("150")).Name;
            string expectedResult = "25";

            Assert.AreEqual(expectedResult, result);

        }

        [TestMethod]
        public void UnitConversion()
        {
            string valueInInches = "2";
            string expectedResult = "5.08";

            Keyboard.Instance.HoldKey(KeyboardInput.SpecialKeys.CONTROL);
            Keyboard.Instance.Enter("u");
            Keyboard.Instance.LeaveKey(KeyboardInput.SpecialKeys.CONTROL);

            var typeComboBox = win.Get<ComboBox>(SearchCriteria.ByAutomationId("221"));
            typeComboBox.Select("Length");

            var fromComboBox = win.Get<ComboBox>(SearchCriteria.ByAutomationId("224"));
            fromComboBox.Select("Inch");

            var toComboBox = win.Get<ComboBox>(SearchCriteria.ByAutomationId("225"));
            toComboBox.Select("Centimeters");

            var fromTextBox = win.Get(SearchCriteria.ByAutomationId("226"));
            fromTextBox.SetValue(valueInInches);
            string result = win.Get<TextBox>(SearchCriteria.ByAutomationId("227")).Text;

            Assert.AreEqual(result, expectedResult);
        }

        [TestMethod]
        public void DateCalculation()
        {
            string expectedDate = "Wednesday, October 07, 2015";
            Keyboard.Instance.HoldKey(KeyboardInput.SpecialKeys.CONTROL);
            Keyboard.Instance.Enter("e");
            Keyboard.Instance.LeaveKey(KeyboardInput.SpecialKeys.CONTROL);

            var typeComboBox = win.Get<ComboBox>(SearchCriteria.ByAutomationId("4003"));
            typeComboBox.Select("Add or subtract days to a specified date");

            var subtractRadioBtn = win.Get<RadioButton>(SearchCriteria.ByAutomationId("4016"));
            subtractRadioBtn.Click();

            var monthSpinner = win.Get<Spinner>(SearchCriteria.ByAutomationId("4022"));
            for (int i = 0; i <= 5; i++)
            {
                monthSpinner.Increment();
            }
            Button calculateBtn = win.Get<Button>(SearchCriteria.ByAutomationId("4015"));
            calculateBtn.Click();

            string result = win.Get<TextBox>(SearchCriteria.ByAutomationId("4013")).Text;

            Assert.AreEqual(expectedDate, result );
        }

        [TestCleanup]
		public void Cleanup()
		{
			app.Close();
		}
	}
}
